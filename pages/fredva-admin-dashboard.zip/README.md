# Fred VA Admin Dashboard
This dashboard is designed for Fred Otieno's virtual assistant bot.