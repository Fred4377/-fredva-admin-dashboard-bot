import React from 'react';

export default function Home() {
  return <div>Welcome to Fred VA Admin Dashboard - Bot is LIVE ✅</div>;
}